// static/custom/calendar_range_map.js
// No-op: calendar_range now exposes luogo_id, so the generic map_overlay.js handles the map button uniformly.
(function(){ /* intentionally left blank */ })();
