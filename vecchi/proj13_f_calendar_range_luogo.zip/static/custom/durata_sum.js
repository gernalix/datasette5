(function() {
  function parseDate(d) { return d ? new Date(d.replace(" ", "T")) : null; }
  function diffHours(a,b) {
    const da=parseDate(a), db=parseDate(b);
    if(!da||!db) return null;
    return (db - da) / 3600000;
  }
  function addDurataSum() {
    const tbl=document.querySelector("table.rows-and-columns");
    if(!tbl) return;
    const headers=[...tbl.querySelectorAll("th")].map(th=>th.textContent.trim().toLowerCase());
    const idxInizio=headers.indexOf("inizio");
    const idxFine=headers.indexOf("fine");
    if(idxInizio==-1||idxFine==-1) return;
    const rows=[...tbl.querySelectorAll("tbody tr")];
    let total=0, count=0;
    rows.forEach(tr=>{
      const tds=tr.querySelectorAll("td");
      const dur=diffHours(tds[idxInizio].textContent, tds[idxFine].textContent);
      if(dur!=null){ total+=dur; count++; }
    });
    const p=document.createElement("div");
    p.textContent=`Totale: ${total.toFixed(2)} ore (${count} righe)`;
    p.style="margin:10px 0;font-weight:bold;";
    tbl.insertAdjacentElement("afterend",p);
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",addDurataSum);
  else addDurataSum();
})();
