/*
  map_overlay.js — uses luogo_id/lat/lon for calendar_range to speed up rendering.
  Falls back to address geocoding only if lat/lon are missing.
*/
(function(){
  function val(x){ return (x==null ? "" : (""+x)).trim(); }
  function num(x){
    const n = parseFloat(x);
    return Number.isFinite(n) ? n : null;
  }
  function buildMarker(map, row){
    const lat = num(row.lat);
    const lon = num(row.lon);
    if (lat!=null && lon!=null){
      const m = L.marker([lat, lon]);
      const label = (row.tabella ? (row.tabella + " #" + row.riga_id) : (row.riga_id ? ("#" + row.riga_id) : ""));
      const addr  = val(row.indirizzo);
      const popup = [label, addr].filter(Boolean).join("<br>");
      m.bindPopup(popup || ""); 
      m.addTo(map);
      return true;
    }
    // Fallback: try address geocoding if available (older tables)
    if (row.indirizzo && window.getLatLonFromAddress){
      return getLatLonFromAddress(row.indirizzo).then(coords => {
        const m = L.marker(coords).addTo(map);
        m.bindPopup(val(row.indirizzo));
      });
    }
    return false;
  }

  // Entry point used by the "Mappa indirizzi" button
  window.renderAddressMap = async function(rows){
    // Create map container if not present
    let container = document.getElementById("address-map");
    if(!container){
      container = document.createElement("div");
      container.id = "address-map";
      container.style = "height: 520px; margin: 10px 0; border-radius: 12px;";
      const anchor = document.querySelector("h1, h2, header") || document.body;
      anchor.parentNode.insertBefore(container, anchor.nextSibling);
    }
    container.innerHTML = "";
    const map = L.map(container).setView([55.6761, 12.5683], 12); // Copenhagen default
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    let any = false;
    for (const row of rows){
      const res = buildMarker(map, row);
      if (res) any = true;
    }
    if (!any){
      const p = document.createElement("p");
      p.textContent = "Nessun punto disponibile (mancano lat/lon e indirizzo).";
      container.appendChild(p);
    }
  };
})();