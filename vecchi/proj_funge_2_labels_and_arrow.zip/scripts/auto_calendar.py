# -*- coding: utf-8 -*-
"""
auto_calendar.py (PID-aware)
- Verifica che l'istanza registrata in datasette.pid sia **viva**; se è un PID zombie, pulisce il file
- Mantiene debounce, grace, wait-unlock, cooldown
"""

from __future__ import annotations

import os
import time
import sqlite3
import subprocess
from datetime import datetime
from typing import Sequence, Tuple, Optional

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(THIS_DIR)

OUTPUT_DB = os.path.join(BASE_DIR, "output.db")
RUN_LOG = os.path.join(BASE_DIR, "run.log")
PID_FILE = os.path.join(BASE_DIR, "datasette.pid")

PYTHON_EXE = "python"

DEBOUNCE_SECONDS = 3.0
POLL_INTERVAL = 1.0
GRACE_AFTER_SAVE = 2.0
UNLOCK_TIMEOUT = 45.0
UNLOCK_CHECK_EVERY = 0.5
COOLDOWN_SECONDS = 8.0
HEARTBEAT_EVERY = 30.0

def ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_line(message: str) -> None:
    line = f"{ts()} {message}"
    print(line, flush=True)
    try:
        with open(RUN_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def run_logged(cmd: Sequence[str], desc: str, cwd: Optional[str] = None):
    log_line(f"▶ {desc}")
    log_line(f"   CMD: {cmd}")
    try:
        proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, shell=False)
    except Exception as e:
        log_line(f"❌ {desc} — EXCEPTION: {e!r}")
        return False, -1

    if proc.stdout:
        log_line("— STDOUT —")
        for line in proc.stdout.splitlines():
            log_line(f"   {line}")
    if proc.stderr:
        log_line("— STDERR —")
        for line in proc.stderr.splitlines():
            log_line(f"   {line}")

    if proc.returncode == 0:
        log_line(f"✅ {desc} — OK (rc={proc.returncode})")
        return True, 0
    else:
        log_line(f"❌ {desc} — FAILED (rc={proc.returncode})")
        return False, proc.returncode

def get_file_sig(path: str):
    try:
        st = os.stat(path)
        return (st.st_mtime, st.st_size)
    except Exception:
        return None

def can_acquire_write_lock(db_path: str) -> bool:
    try:
        conn = sqlite3.connect(db_path, timeout=0.1, isolation_level=None)
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("ROLLBACK")
            return True
        finally:
            conn.close()
    except sqlite3.OperationalError:
        return False
    except Exception:
        return False

def wait_until_unlocked(db_path: str, timeout_s: float, every_s: float) -> bool:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if can_acquire_write_lock(db_path):
            return True
        log_line("🔒 DB occupato (probabilmente DBeaver). Ritento...")
        time.sleep(every_s)
    return False

def pid_running(pid: int) -> bool:
    try:
        out = subprocess.check_output(["tasklist", "/FI", f"PID eq {pid}"], text=True, creationflags=0x08000000)
        return str(pid) in out
    except Exception:
        return False

def write_pid_file(pid: int) -> None:
    try:
        with open(PID_FILE, "w", encoding="utf-8") as f:
            f.write(str(pid))
    except Exception:
        pass

def read_pid_file() -> Optional[int]:
    try:
        with open(PID_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            return int(content) if content else None
    except Exception:
        return None

def ensure_pidfile_integrity() -> None:
    pid = read_pid_file()
    if pid and not pid_running(pid):
        log_line(f"🧹 PID file obsoleto rilevato ({pid}), lo rimuovo.")
        try:
            os.remove(PID_FILE)
        except Exception:
            pass

def main() -> int:
    log_line("👂 In ascolto SOLO su output.db (debounce 3s)...")
    log_line(f"📁 BASE_DIR: {BASE_DIR}")
    log_line(f"📄 OUTPUT_DB: {OUTPUT_DB}")
    log_line(f"🐍 Python: {PYTHON_EXE}")
    last_sig = get_file_sig(OUTPUT_DB)
    if last_sig is None:
        log_line("⚠️ output.db non trovato al primo avvio. Attendo che compaia...")

    last_fire_ts: float = 0.0
    ignore_until_ts: float = 0.0
    last_heartbeat: float = time.time()

    while True:
        try:
            now = time.time()
            sig = get_file_sig(OUTPUT_DB)

            # Heartbeat + pulizia PID zombie
            if now - last_heartbeat >= HEARTBEAT_EVERY:
                log_line("⏳ idle...")
                ensure_pidfile_integrity()
                last_heartbeat = now

            if sig is None:
                time.sleep(POLL_INTERVAL)
                continue

            if now < ignore_until_ts:
                time.sleep(POLL_INTERVAL)
                last_sig = sig
                continue

            if last_sig is None or sig != last_sig:
                if now - last_fire_ts >= DEBOUNCE_SECONDS:
                    last_fire_ts = now
                    log_line(f"📎 output.db modificato: mtime={sig[0]:.0f} size={sig[1]}")

                    if GRACE_AFTER_SAVE > 0:
                        log_line(f"⏳ Attendo {GRACE_AFTER_SAVE:.1f}s per consentire a DBeaver di chiudere la connessione...")
                        time.sleep(GRACE_AFTER_SAVE)

                    log_line(f"🕵️ Verifico disponibilità lock in scrittura (timeout {UNLOCK_TIMEOUT:.0f}s)...")
                    if not wait_until_unlocked(OUTPUT_DB, UNLOCK_TIMEOUT, UNLOCK_CHECK_EVERY):
                        log_line("⛔ Timeout attesa unlock: salto questa build per evitare corruzione.")
                    else:
                        ok, _ = run_logged(
                            [PYTHON_EXE, "scripts/build_calendar.py", "output.db",
                             os.path.join("static", "custom", "calendar_columns.txt"),
                             "--base-path", "/output"],
                            "Eseguo build calendario", cwd=BASE_DIR
                        )
                        if ok:
                            log_line("✅ Calendario rigenerato con successo.")
                            # Launch if not already running
                            pid = read_pid_file()
                            if pid and pid_running(pid):
                                log_line(f"🛑 Salto nuovo avvio: server già attivo (PID {pid}).")
                            else:
                                if pid and not pid_running(pid):
                                    log_line(f"🧹 Rimuovo PID obsoleto ({pid}) prima di rilanciare.")
                                    try: os.remove(PID_FILE)
                                    except Exception: pass

                                try:
                                    proc = subprocess.Popen([PYTHON_EXE, "scripts/launch_datasette.py"],
                                                            cwd=BASE_DIR,
                                                            stdout=subprocess.DEVNULL,
                                                            stderr=subprocess.DEVNULL,
                                                            shell=False)
                                    write_pid_file(proc.pid)
                                    log_line(f"🚀 Datasette avviato in background (PID {proc.pid}).")
                                except Exception as e:
                                    log_line(f"⚠️ Avvio in background fallito: {e!r}")

                            ignore_until_ts = time.time() + COOLDOWN_SECONDS
                        else:
                            log_line("⛔ Build calendario fallita: salto riavvio Datasette.")

                last_sig = sig

            time.sleep(POLL_INTERVAL)
        except KeyboardInterrupt:
            log_line("👋 Interrotto da tastiera. Esco.")
            return 0
        except Exception as e:
            log_line(f"💥 Eccezione nel loop: {e!r}")
            time.sleep(1.5)

if __name__ == "__main__":
    raise SystemExit(main())
