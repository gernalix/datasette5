// Rimuove blocchi SQL delle VIEW (CREATE VIEW ...) su qualunque tabella/view.
(function () {
  const hasCreateView = /(^|\n|\r)\s*CREATE\s+VIEW\s+/i;

  function nukeSqlBlocks() {
    // 1) elimina <pre> e <code> che contengono "CREATE VIEW"
    document.querySelectorAll('pre, code').forEach(el => {
      const txt = (el.textContent || "");
      if (hasCreateView.test(txt)) {
        // se c'è un heading immediatamente sopra, toglilo
        const prev = el.previousElementSibling;
        if (prev && /^H[1-6]$/i.test(prev.tagName)) prev.remove();

        // prova a rimuovere il contenitore logico
        let node = el;
        while (node && node.parentElement) {
          const tag = (node.tagName || "").toLowerCase();
          if (tag === 'section' || tag === 'div' || tag === 'article') {
            node.remove();
            return;
          }
          node = node.parentElement;
        }
        // fallback: rimuovi solo il blocco
        el.remove();
      }
    });

    // 2) rimuovi eventuali dettagli/summary che mostrano SQL
    document.querySelectorAll('details, summary').forEach(el => {
      const txt = (el.textContent || "");
      if (hasCreateView.test(txt)) {
        const parent = el.closest('details') || el.parentElement;
        if (parent) parent.remove(); else el.remove();
      }
    });
  }

  // esegui subito
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', nukeSqlBlocks);
  } else {
    nukeSqlBlocks();
  }

  // osserva cambiamenti (navigazione interna, ricarichi parziali ecc.)
  const mo = new MutationObserver(nukeSqlBlocks);
  mo.observe(document.documentElement, { childList: true, subtree: true });
})();
