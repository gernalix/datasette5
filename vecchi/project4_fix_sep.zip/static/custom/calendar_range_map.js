// static/custom/calendar_range_map.js
(function(){
  function onReady(fn){
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }
  function isCalendarRange(){
    return /\/calendar_range(?:$|[/?#])/.test(location.pathname);
  }
  function btn(){
    const h1=document.querySelector("h1");
    if(!h1) return;
    const b=document.createElement("button");
    b.textContent="🗺️ Mappa indirizzi";
    b.className="btn btn-sm";
    b.style.marginLeft="1rem";
    b.addEventListener("click", run);
    h1.appendChild(b);
  }
  function jsonURL(path){
    const u=new URL(location.href);
    u.pathname=path || (u.pathname.replace(/\/$/,"") + ".json");
    u.searchParams.set("_shape","objects");
    u.searchParams.set("_size","max");
    return u.toString();
  }
  function ensureLeaflet(){
    if (window.L && L.map) return Promise.resolve();
    const link=document.createElement("link");
    link.rel="stylesheet";
    link.href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    return new Promise((res,rej)=>{
      const s=document.createElement("script");
      s.src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
      s.onload=res; s.onerror=rej;
      document.head.appendChild(s);
    });
  }
  async function run(){
    try{
      const rows = await (await fetch(jsonURL(), {credentials:"same-origin"})).json();
      const items=[];
      const whitelist=new Set(["sex","ex_sex","ex_negozi","ex_super","negozi","luogo"]);
      for(const r of rows){
        const tab=(r.tab||"").toString();
        if(!whitelist.has(tab)) continue;
        let pk=null;
        try{ pk=(typeof r.pk_json==="string")? JSON.parse(r.pk_json): r.pk_json; }catch(e){}
        const id= pk && (pk.id || pk.pk || pk.rowid);
        if(!id) continue;
        // fetch record to get luogo_id
        const base=new URL(location.href);
        base.pathname = base.pathname.replace(/\/calendar_range.*/,"") + "/" + encodeURIComponent(tab) + "/" + encodeURIComponent(id) + ".json";
        base.search="?_shape=objects&_size=1";
        const recArr = await (await fetch(base.toString(), {credentials:"same-origin"})).json();
        const rec = Array.isArray(recArr)? recArr[0]: null;
        const luogo_id = rec && (rec.luogo_id ?? null);
        if(luogo_id!=null) items.push(luogo_id);
      }
      const ids=[...new Set(items)];
      if(!ids.length){ alert("Nessun luogo disponibile per questa selezione."); return; }
      await ensureLeaflet();
      const modal=document.createElement("div");
      modal.style.position="fixed"; modal.style.inset="5%"; modal.style.background="white";
      modal.style.border="1px solid #ccc"; modal.style.zIndex=9999; modal.style.boxShadow="0 10px 30px rgba(0,0,0,.3)";
      const close=document.createElement("button"); close.textContent="✖"; close.style.position="absolute"; close.style.top="8px"; close.style.right="8px"; close.onclick=()=>modal.remove();
      const mapDiv=document.createElement("div"); mapDiv.style.position="absolute"; mapDiv.style.top="48px"; mapDiv.style.left=0; mapDiv.style.right=0; mapDiv.style.bottom=0;
      modal.appendChild(close); modal.appendChild(mapDiv); document.body.appendChild(modal);
      const m=L.map(mapDiv).setView([55.6761,12.5683], 11);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(m);
      const m2=location.pathname.match(/^\/([^/]+)/); const db = m2? m2[1]: "output";
      for(const id of ids){
        const u=new URL(location.href);
        u.pathname = "/" + db + "/luogo/" + encodeURIComponent(id) + ".json";
        u.search="?_shape=objects&_size=1";
        const arr = await (await fetch(u.toString(),{credentials:"same-origin"})).json();
        const rec = Array.isArray(arr)? arr[0]: null;
        if(!rec) continue;
        const lat= rec.lat ?? rec.latitude;
        const lon= rec.lon ?? rec.longitude ?? rec.lng;
        if(lat==null || lon==null) continue;
        const marker=L.marker([+lat,+lon]).addTo(m);
        marker.bindPopup(rec.indirizzo || ("luogo #" + id));
      }
      try{ m.fitBounds(m.getBounds().pad(0.2)); }catch(e){}
    }catch(e){
      console.error("calendar_range_map error", e);
      alert("Errore durante il caricamento della mappa.");
    }
  }
  onReady(function(){
    if(!isCalendarRange()) return;
    btn();
  });
})();