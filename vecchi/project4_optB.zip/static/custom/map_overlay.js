
// static/custom/map_overlay.js  (Option B for calendar_range)
(function(){
  const MAX_FETCH_SIZE = "max";
  const TARGET_COL = "luogo_id";
  const TAB_WHITELIST = new Set(["sex", "ex_sex", "ex_negozi", "ex_super", "negozi", "luogo"]);

  function onReady(fn){
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }

  function ensureLeaflet(){
    if (window.L && L.map) return Promise.resolve();
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    return new Promise(function(resolve, reject){
      var s = document.createElement("script");
      s.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  function currentJsonUrl(){
    var url = new URL(window.location.href);
    url.pathname = url.pathname.replace(/\/$/, "") + ".json";
    var q = url.searchParams;
    q.set("_shape", "objects");
    q.set("_size", MAX_FETCH_SIZE);
    return url.toString();
  }

  function hasLuogoIdColumn(){
    var ths = Array.from(document.querySelectorAll("table th"));
    return ths.some(th => (th.textContent || "").trim() === TARGET_COL);
  }

  function isCalendarRange(){
    return /\/calendar_range(?:$|[/?#])/.test(location.pathname);
  }

  async function calendarHasEligibleRows(){
    try{
      const resp = await fetch(currentJsonUrl(), {credentials:"same-origin"});
      if (!resp.ok) return false;
      const rows = await resp.json();
      if (!Array.isArray(rows)) return false;
      for (const r of rows){
        const tab = (r.tab || "").toString();
        if (TAB_WHITELIST.has(tab)) return true;
      }
      return false;
    }catch(e){ console.warn("calendarHasEligibleRows error", e); return false; }
  }

  function insertButton(){
    var h1 = document.querySelector("h1");
    if (!h1) return;
    var btn = document.createElement("button");
    btn.textContent = "🗺️ Mappa indirizzi";
    btn.className = "btn btn-sm";
    btn.style.marginLeft = "1rem";
    btn.addEventListener("click", showMapForCurrentPage);
    h1.appendChild(btn);
  }

  async function showMapForCurrentPage(){
    const markers = [];
    if (hasLuogoIdColumn()){
      const rows = await (await fetch(currentJsonUrl(), {credentials:"same-origin"})).json();
      for (const r of rows){
        const id = r[TARGET_COL];
        if (id != null) markers.push({luogo_id: id});
      }
    } else if (isCalendarRange()){
      const rows = await (await fetch(currentJsonUrl(), {credentials:"same-origin"})).json();
      for (const r of rows){
        const tab = (r.tab || "").toString();
        if (!TAB_WHITELIST.has(tab)) continue;
        let pk = null;
        try { pk = (typeof r.pk_json === "string") ? JSON.parse(r.pk_json) : r.pk_json; } catch(e){ pk = null; }
        const id = pk && (pk.id || pk.pk || pk.rowid);
        if (!id) continue;
        const base = new URL(location.href);
        base.pathname = base.pathname.replace(/\/calendar_range.*/,"") + "/" + encodeURIComponent(tab) + "/" + encodeURIComponent(id) + ".json";
        base.search = "?_shape=objects&_size=1";
        try{
          const recResp = await fetch(base.toString(), {credentials:"same-origin"});
          if (!recResp.ok) continue;
          const arr = await recResp.json();
          const rec = Array.isArray(arr) ? arr[0] : null;
          if (rec && rec[TARGET_COL] != null){
            markers.push({luogo_id: rec[TARGET_COL]});
          }
        }catch(e){ /* ignore */}
      }
    }
    if (!markers.length){
      alert("Nessun luogo disponibile per questa selezione.");
      return;
    }
    await openMap(markers);
  }

  async function openMap(items){
    await ensureLeaflet();
    const modal = document.createElement("div");
    modal.style.position = "fixed";
    modal.style.inset = "5%";
    modal.style.background = "white";
    modal.style.border = "1px solid #ccc";
    modal.style.zIndex = 9999;
    modal.style.boxShadow = "0 10px 30px rgba(0,0,0,.3)";
    const close = document.createElement("button");
    close.textContent = "✖";
    close.style.position = "absolute";
    close.style.top = "8px";
    close.style.right = "8px";
    close.onclick = ()=> modal.remove();
    const mapDiv = document.createElement("div");
    mapDiv.id = "map-overlay";
    mapDiv.style.position = "absolute";
    mapDiv.style.top = "48px";
    mapDiv.style.left = "0";
    mapDiv.style.right = "0";
    mapDiv.style.bottom = "0";
    modal.appendChild(close);
    modal.appendChild(mapDiv);
    document.body.appendChild(modal);

    const m = L.map(mapDiv).setView([55.6761,12.5683], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap'
    }).addTo(m);

    const ids = Array.from(new Set(items.map(i => i.luogo_id))).filter(Boolean);
    for (const id of ids){
      try{
        const base = new URL(location.href);
        const m2 = location.pathname.match(/^\/([^/]+)/);
        const db = m2 ? m2[1] : "output";
        base.pathname = "/" + db + "/luogo/" + encodeURIComponent(id) + ".json";
        base.search = "?_shape=objects&_size=1";
        const resp = await fetch(base.toString(), {credentials:"same-origin"});
        if (!resp.ok) continue;
        const arr = await resp.json();
        const rec = Array.isArray(arr) ? arr[0] : null;
        if (!rec) continue;
        const lat = rec.lat || rec.latitude;
        const lon = rec.lon || rec.longitude || rec.lng;
        if (lat == null || lon == null) continue;
        const marker = L.marker([+lat, +lon]).addTo(m);
        const caption = rec.indirizzo || ("luogo #" + id);
        marker.bindPopup(caption);
      }catch(e){}
    }
    try { m.fitBounds(m.getBounds().pad(0.2)); } catch(e){}
  }

  async function shouldActivate(){
    if (hasLuogoIdColumn()) return true;
    if (isCalendarRange()){
      return await calendarHasEligibleRows();
    }
    return false;
  }

  onReady(async function(){
    if (!(await shouldActivate())) return;
    var link = document.querySelector('link[href="/custom/map_overlay.css"]');
    if (!link){
      link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = "/custom/map_overlay.css";
      document.head.appendChild(link);
    }
    insertButton();
  });
})();
