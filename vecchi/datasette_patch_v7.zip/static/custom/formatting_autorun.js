(function(){
  function run(){ try { window.applyFormatting && window.applyFormatting(); } catch(e){ console.warn('applyFormatting error:', e); } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
  // Also after a short delay (for client-side rendered parts)
  setTimeout(run, 100);
})();