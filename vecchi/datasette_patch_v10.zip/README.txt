Istruzioni:
1) Copia static/custom/durata_sum.js nel tuo progetto (static/custom/)
2) Aggiungi in templates/base.html la riga:
   <script defer src="/custom/durata_sum.js?v=2"></script>
