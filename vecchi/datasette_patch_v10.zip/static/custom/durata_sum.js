// static/custom/durata_sum.js v2
(function(){
  function parseYMD(txt){
    const m = txt.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if(!m) return null;
    const y = +m[1], mo = +m[2]-1, d = +m[3];
    const hh = m[4] ? +m[4] : 0, mm = m[5] ? +m[5] : 0, ss = m[6] ? +m[6] : 0;
    return new Date(y, mo, d, hh, mm, ss);
  }
  function parseDMY(txt){
    const m = txt.match(/^(\d{2})[-/](\d{2})[-/](\d{2}|\d{4})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if(!m) return null;
    const d = +m[1], mo = +m[2]-1;
    let y = m[3].length === 2 ? (+m[3] < 70 ? 2000 + +m[3] : 1900 + +m[3]) : +m[3];
    const hh = m[4] ? +m[4] : 0, mm = m[5] ? +m[5] : 0, ss = m[6] ? +m[6] : 0;
    return new Date(y, mo, d, hh, mm, ss);
  }
  function parseDateSmart(txt){
    if(!txt) return null;
    txt = String(txt).trim();
    txt = txt.replace(/([+-]\d{2}:\d{2}|Z)$/i, "");
    txt = txt.replace(/\s+/g, " ");
    let d = parseYMD(txt) || parseDMY(txt);
    if(!d || isNaN(d.getTime())){
      const t = txt.replace(" ", "T");
      d = parseYMD(t) || parseDMY(t);
    }
    return (d && !isNaN(d)) ? d : null;
  }
  function diffHours(a, b){
    const da = parseDateSmart(a);
    const db = parseDateSmart(b);
    if(!da || !db) return null;
    return (db.getTime() - da.getTime()) / 3600000;
  }
  function addFooter(){
    const table = document.querySelector("table.rows-and-columns");
    if(!table) return;
    const headers = Array.from(table.querySelectorAll("th")).map(th => th.textContent.trim().toLowerCase());
    const idxInizio = headers.indexOf("inizio");
    const idxFine   = headers.indexOf("fine");
    if(idxInizio === -1 || idxFine === -1) return;
    const existing = document.querySelector("#durata-sum-footer");
    if (existing) existing.remove();
    let total = 0, count = 0;
    Array.from(table.querySelectorAll("tbody tr")).forEach(tr => {
      const tds = tr.querySelectorAll("td");
      if (tds.length <= Math.max(idxInizio, idxFine)) return;
      const hours = diffHours(tds[idxInizio].textContent, tds[idxFine].textContent);
      if (hours != null && !isNaN(hours)) { total += hours; count++; }
    });
    const div = document.createElement("div");
    div.id = "durata-sum-footer";
    div.style = "margin:10px 0;font-weight:bold;";
    div.textContent = `Totale: ${ (isNaN(total)? '0.00' : total.toFixed(2)) } ore (${count} righe)`;
    table.insertAdjacentElement("afterend", div);
  }
  function run(){
    try{ addFooter(); setTimeout(addFooter, 150); }catch(e){}
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", run, {once:true});
  else run();
})();