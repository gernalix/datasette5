// map_overlay.js — bottone unico + mappa Leaflet self‑contained
(function () {
  const BTN_ID = "btn-map-indirizzi";

  function onTablePage() {
    return /^\/output\/[^\/]+(\/\d+)?$/.test(location.pathname);
  }
  function container() {
    return document.querySelector('.content h1, h1.title, .page-title, h1') || document.body;
  }

  function loadLeaflet(cb) {
    if (window.L && typeof window.L.map === 'function') return cb();
    const head = document.head;
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    head.appendChild(link);
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    s.onload = cb;
    head.appendChild(s);
  }

  function unique(arr) { return Array.from(new Set(arr)); }

  function currentIds() {
    // Raccogli id luogo dalla tabella corrente:
    // 1) celle con data-column="luogo_id"
    // 2) link che puntano a /output/luogo/<id>
    const ids = [];
    document.querySelectorAll('td[data-column="luogo_id"]').forEach(td => {
      const txt = (td.textContent || '').trim();
      if (/^\d+$/.test(txt)) ids.push(Number(txt));
      const a = td.querySelector('a[href*="/output/luogo/"]');
      if (a) {
        const m = a.href.match(/\/output\/luogo\/(\d+)/);
        if (m) ids.push(Number(m[1]));
      }
    });
    document.querySelectorAll('a[href*="/output/luogo/"]').forEach(a => {
      const m = a.href.match(/\/output\/luogo\/(\d+)/);
      if (m) ids.push(Number(m[1]));
    });
    return unique(ids);
  }

  function fetchLuoghi(ids) {
    return fetch('/output/luogo.json?_shape=objects&_size=max&_where=id+in+(' + ids.join(',') + ')')
      .then(r => r.json());
  }

  function ensureOverlay() {
    let overlay = document.getElementById('addr-map-overlay');
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.id = 'addr-map-overlay';
    overlay.style.cssText = 'position:fixed;inset:4% 4% 8% 4%;background:#fff;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.3);z-index:99999;display:flex;flex-direction:column;overflow:hidden';
    overlay.innerHTML = '<div style="padding:8px 12px;border-bottom:1px solid #ddd;display:flex;gap:8px;align-items:center"><strong>🗺️ Mappa indirizzi</strong><span id="addr-map-count" style="opacity:.7;margin-left:8px"></span><button id="addr-map-close" class="btn" style="margin-left:auto">Chiudi</button></div><div id="addr-map" style="flex:1 1 auto"></div>';
    document.body.appendChild(overlay);
    overlay.querySelector('#addr-map-close').addEventListener('click', () => overlay.remove());
    return overlay;
  }

  function showMap(features) {
    const overlay = ensureOverlay();
    const mapDiv = overlay.querySelector('#addr-map');
    mapDiv.innerHTML = '';
    loadLeaflet(() => {
      const map = L.map(mapDiv).setView([55.676,12.568], 12); // Copenhagen default
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap'
      }).addTo(map);
      const group = L.featureGroup();
      features.forEach(r => {
        const lat = r.lat || r.latitude || r.y || r.latitudine;
        const lon = r.lon || r.lng || r.x || r.longitudine;
        if (typeof lat === 'number' && typeof lon === 'number') {
          const m = L.marker([lat, lon]).bindPopup((r.indirizzo || r.nome || ('luogo ' + r.id)) + '<br><a href="/output/luogo/' + r.id + '">Apri riga</a>');
          m.addTo(group);
        }
      });
      if (group.getLayers().length) {
        group.addTo(map);
        map.fitBounds(group.getBounds().pad(0.2));
      }
      overlay.querySelector('#addr-map-count').textContent = '(' + features.length + ' elementi)';
    });
  }

  function handleClick(e) {
    e.preventDefault();
    const ids = currentIds();
    if (!ids.length) {
      alert('Nessun luogo_id rilevato nella tabella corrente.');
      return;
    }
    fetchLuoghi(ids).then(showMap).catch(err => {
      console.error('Errore fetch luoghi:', err);
      alert('Impossibile caricare i luoghi.');
    });
  }

  function ensureButton() {
    if (!onTablePage()) return;
    if (document.getElementById(BTN_ID)) return;
    const where = container(); if (!where) return;
    const a = document.createElement('a');
    a.id = BTN_ID; a.href = '#'; a.textContent = ' 🗺️ Mappa indirizzi';
    a.className = 'btn btn-secondary'; a.style.marginLeft = '0.6rem';
    a.addEventListener('click', handleClick);
    where.insertAdjacentElement('afterend', a);
  }

  document.addEventListener('DOMContentLoaded', ensureButton);
  new MutationObserver(ensureButton).observe(document.documentElement, { childList: true, subtree: true });
})();