/*
  map_overlay.js — preferisce lat/lon (da luogo) per calendar_range.
  Fallback su geocoding indirizzo solo se mancano lat/lon.
*/
(function(){
  function s(x){ return (x==null ? "" : (""+x)).trim(); }
  function n(x){ const v = parseFloat(x); return Number.isFinite(v) ? v : null; }

  function addMarker(map, row){
    const lat = n(row.lat);
    const lon = n(row.lon);
    if (lat!=null && lon!=null){
      const m = L.marker([lat, lon]).addTo(map);
      const label = (row.tabella ? (row.tabella + " #" + row.riga_id) : (row.riga_id ? ("#" + row.riga_id) : ""));
      const addr  = s(row.indirizzo);
      const html  = [label, addr].filter(Boolean).join("<br>");
      if (html) m.bindPopup(html);
      return true;
    }
    if (row.indirizzo && window.getLatLonFromAddress){
      return getLatLonFromAddress(row.indirizzo).then(coords => {
        const m = L.marker(coords).addTo(map);
        m.bindPopup(s(row.indirizzo));
      });
    }
    return false;
  }

  window.renderAddressMap = async function(rows){
  // create container if not exists
  let el = document.getElementById("address-map");
  if(!el){
    el = document.createElement("div");
    el.id = "address-map";
    el.style = "height:520px;margin:10px 0;border-radius:12px;";
    const anchor = document.querySelector("h1, h2, header") || document.body;
    anchor.parentNode.insertBefore(el, anchor.nextSibling);
  }
  el.innerHTML = "";
  const map = L.map(el);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
  }).addTo(map);

  const points = [];
  for (const row of rows){
    const lat = parseFloat(row.lat);
    const lon = parseFloat(row.lon);
    if (Number.isFinite(lat) && Number.isFinite(lon)){
      const m = L.marker([lat, lon]).addTo(map);
      const label = (row.tabella ? (row.tabella + " #" + row.riga_id) : (row.riga_id ? ("#" + row.riga_id) : ""));
      const addr  = (row.indirizzo ?? "").toString().trim();
      const html  = [label, addr].filter(Boolean).join("<br>");
      if (html) m.bindPopup(html);
      points.push([lat, lon]);
    } else if (row.indirizzo && window.getLatLonFromAddress && !(row.tabella === 'calendar_range')) {
      // Only fallback geocoding for non-calendar_range tables
      const coords = await getLatLonFromAddress(row.indirizzo);
      const m = L.marker(coords).addTo(map);
      m.bindPopup(row.indirizzo);
      points.push(coords);
    }
  }
  if (points.length){
    const bounds = L.latLngBounds(points);
    map.fitBounds(bounds.pad(0.15));
  } else {
    // Fallback to Copenhagen center if nothing
    map.setView([55.6761, 12.5683], 12);
    const p = document.createElement("p");
    p.textContent = "Nessun punto disponibile";
    el.appendChild(p);
  }
};
})();