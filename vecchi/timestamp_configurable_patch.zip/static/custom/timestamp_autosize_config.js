
/*! Timestamp Auto-Width (Configurable) for Datasette
 * - Reads /custom/timestamp_columns.txt
 * - Supports wildcards for table and column names
 * - Removes <br> in target cells; forces nowrap; dynamic min-width (in ch)
 * - Safe to include alongside your existing custom JS/CSS
 */
(function () {
  const CONFIG_URL = '/custom/timestamp_columns.txt';
  const FALLBACK_PATTERNS = ['inizio','fine','*_at','*_timestamp','*_time','*_date'];

  function onReady(fn){ if(document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  function getTableNameFromURL() {
    try {
      const parts = location.pathname.split('/').filter(Boolean);
      // Expect .../<db>/<table>/... — table is the 2nd segment
      if (parts.length >= 2) return decodeURIComponent(parts[1]).toLowerCase();
    } catch(e){}
    // Fallback: H1 text
    const h1 = document.querySelector('h1');
    return h1 ? (h1.textContent || '').trim().toLowerCase() : '';
  }

  function parseConfig(text) {
    const out = { '*': [] };
    text.split(/\r?\n/).forEach(line => {
      line = line.trim();
      if (!line || line.startsWith('#')) return;
      const m = line.split(':');
      if (m.length < 2) return;
      const table = m[0].trim().toLowerCase();
      const cols = m.slice(1).join(':').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
      if (!out[table]) out[table] = [];
      out[table].push(...cols);
    });
    return out;
  }

  function wildcardMatch(name, pattern) {
    // simple '*' wildcard (prefix/suffix/infix)
    name = name.toLowerCase();
    pattern = pattern.toLowerCase();
    if (pattern === '*') return true;
    const esc = s => s.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
    const re = new RegExp('^' + esc(pattern) + '$');
    return re.test(name);
  }

  function targetColumns(headers, tableName, cfg) {
    const want = new Set();
    const patterns = (cfg[tableName] || []).concat(cfg['*'] || []);
    // if config empty, fallback
    const pats = patterns.length ? patterns : FALLBACK_PATTERNS;
    headers.forEach((th, idx) => {
      const name = (th.textContent || '').trim().toLowerCase();
      if (!name) return;
      for (const p of pats) {
        if (wildcardMatch(name, p)) {
          want.add(idx);
          break;
        }
      }
    });
    return want;
  }

  function unbreakBr(td){ td.querySelectorAll('br').forEach(br => br.replaceWith(document.createTextNode(' '))); }
  function visibleLen(node){
    const a = node.querySelector ? node.querySelector('a') : null;
    const text = a ? (a.textContent || a.href || '') : (node.textContent || '');
    return text.trim().length;
  }

  function applyAutosize(table, indices) {
    const heads = table.querySelectorAll('thead th');
    indices.forEach(idx => {
      const th = heads[idx];
      let maxLen = Math.max(visibleLen(th), 0);
      const cells = table.querySelectorAll('tbody tr td:nth-child(' + (idx + 1) + ')');
      cells.forEach(td => {
        unbreakBr(td);
        maxLen = Math.max(maxLen, visibleLen(td));
        td.classList.add('ts-no-wrap');
      });
      const minCh = 18, maxCh = 36;
      const width = Math.max(minCh, Math.min(maxCh, maxLen + 2));
      th.classList.add('ts-no-wrap');
      th.style.minWidth = width + 'ch';
      cells.forEach(td => { td.style.minWidth = width + 'ch'; });
    });
  }

  function strongCSS() {
    const s = document.createElement('style');
    s.textContent = `
      table.table th.ts-no-wrap, table.table td.ts-no-wrap {
        white-space: nowrap !important;
        word-break: normal !important;
        overflow-wrap: normal !important;
        hyphens: manual !important;
      }
      .table-wrapper, .content, table.table { overflow-x: auto; }
    `;
    document.head.appendChild(s);
  }

  async function run() {
    strongCSS();
    const table = document.querySelector('table.table');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th'));
    const tableName = getTableNameFromURL();

    let cfg = { '*': [] };
    try {
      const res = await fetch(CONFIG_URL, { cache: 'no-store' });
      if (res.ok) cfg = parseConfig(await res.text());
    } catch (e) { /* ignore, use fallback */ }

    const cols = targetColumns(headers, tableName, cfg);
    if (cols.size) applyAutosize(table, cols);
  }

  onReady(run);
})();
