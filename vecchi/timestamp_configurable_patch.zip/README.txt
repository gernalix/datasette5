# Configurable Timestamp Auto-Width Patch

1) Put these files into your project:
   - static/custom/timestamp_autosize_config.js
   - static/custom/timestamp_columns.txt

2) In templates/base.html include:
   <script defer src="/custom/timestamp_autosize_config.js"></script>

3) Edit `static/custom/timestamp_columns.txt` to list exactly which columns to resize.
   Syntax (case-insensitive, wildcards `*` allowed):
     <table>: <col1>, <col2>, *_timestamp, *_at
   Example:
     sex: inizio, fine
     *: *_at, *_timestamp, *_date, *_time
