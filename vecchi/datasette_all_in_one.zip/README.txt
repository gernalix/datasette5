USO
====
1) Copia 'output.db' in QUESTA cartella.
2) (Opzionale) Modifica static\custom\calendar_columns.txt
3) Doppio clic su: start_datasette.bat
4) Apri: http://localhost:8001/output/calendar_range
