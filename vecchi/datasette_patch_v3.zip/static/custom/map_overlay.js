// map_overlay.js — crea un SOLO bottone e chiama la mappa
(function () {
  const BTN_ID = "btn-map-indirizzi";

  function locateAnchorContainer() {
    // Preferisci il titolo pagina tabella/viste
    return document.querySelector('.content h1, h1.title, .page-title, h1') || document.body;
  }

  function ensureButton() {
    // Mostra su /output/<table> o /output/<view> (+ eventuale /id)
    if (!/^\/output\/[^\/]+(\/\d+)?$/.test(location.pathname)) return;
    if (document.getElementById(BTN_ID)) return;

    const where = locateAnchorContainer();
    if (!where) return;

    const a = document.createElement('a');
    a.id = BTN_ID;
    a.href = '#';
    a.textContent = ' 🗺️ Mappa indirizzi';
    a.className = 'btn btn-secondary';
    a.style.marginLeft = '0.6rem';
    a.addEventListener('click', function (e) {
      e.preventDefault();
      // 1) Funzioni note
      if (typeof window.openAddressMap === 'function') return void window.openAddressMap();
      if (typeof window.renderAddressMapForCurrentTable === 'function') return void window.renderAddressMapForCurrentTable();
      // 2) Eventi noti
      const events = ['ds-open-address-map', 'open-address-map', 'open-map'];
      let fired = false;
      for (const name of events) {
        const ret = window.dispatchEvent(new CustomEvent(name, { bubbles: true }));
        fired = fired || ret;
      }
      if (fired) return;
      // 3) Fallback minimale
      console.warn('map_overlay: nessun handler mappa trovato — fallback no-op');
      alert('Nessun handler mappa trovato: controlla che calendar_range_map.js / fix_links.js definiscano openAddressMap()');
    });
    where.insertAdjacentElement('afterend', a);
  }

  document.addEventListener('DOMContentLoaded', ensureButton);
  new MutationObserver(ensureButton).observe(document.documentElement, { childList: true, subtree: true });
})();
