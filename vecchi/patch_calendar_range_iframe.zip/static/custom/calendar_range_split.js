// static/custom/calendar_range_split.js (iframe version)
// Groups calendar_range by `tab` and embeds the original table pages (same columns & formatting) via iframes.
(function(){
  function isCalendarRange(){ return /\/calendar_range(?:$|[/?#])/.test(location.pathname); }
  function qsa(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }
  function qs(sel, root){ return (root||document).querySelector(sel); }

  function getDbName(){
    const parts = location.pathname.split("/").filter(Boolean);
    return parts[0] || "";
  }

  function parseIdFromHref(href){
    try{
      const u = new URL(href, location.origin);
      const seg = u.pathname.split("/").filter(Boolean);
      const maybeId = seg.pop();
      if (/^\d+$/.test(maybeId)) return maybeId;
      const id = u.searchParams.get("id");
      if (id) return id;
    }catch(e){}
    return null;
  }

  function buildIframeSrc(db, tab, ids){
    const where = "id in (" + ids.join(",") + ")";
    const params = new URLSearchParams({ "_where": where, "_size": "max", "_labels": "on" });
    return `/${db}/${encodeURIComponent(tab)}?` + params.toString();
  }

  async function run(){
    if (!isCalendarRange()) return;
    const baseTable = qs("table.rows-and-columns");
    if(!baseTable) return;

    const headers = qsa("thead th", baseTable).map(th => (th.textContent||"").trim().toLowerCase());
    const tabIdx = headers.indexOf("tab");
    const linkIdx = headers.indexOf("link");
    if (tabIdx === -1 || linkIdx === -1) return;

    const groups = new Map();
    for (const tr of qsa("tbody tr", baseTable)){
      const tds = tr.querySelectorAll("td");
      const tab = (tds[tabIdx]?.textContent || "").trim();
      const a = tds[linkIdx]?.querySelector("a");
      const id = a ? parseIdFromHref(a.href) : null;
      if (!tab || !id) continue;
      if (!groups.has(tab)) groups.set(tab, new Set());
      groups.get(tab).add(id);
    }
    if (!groups.size) return;

    const db = getDbName();
    const container = document.createElement("div");
    container.id = "cr-split-container";
    container.style.marginTop = "1rem";

    for (const [tab, idSet] of groups){
      const ids = Array.from(idSet);
      const h = document.createElement("h2");
      h.textContent = tab;
      h.style.fontSize = "1.15rem";
      h.style.margin = "1.2rem 0 0.5rem";
      container.appendChild(h);

      const iframe = document.createElement("iframe");
      iframe.src = buildIframeSrc(db, tab, ids);
      iframe.style.width = "100%";
      iframe.style.border = "0";
      iframe.loading = "lazy";
      iframe.style.minHeight = Math.max(300, 120 + ids.length * 48) + "px";
      container.appendChild(iframe);
    }

    baseTable.insertAdjacentElement("afterend", container);
    baseTable.style.display = "none";
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run);
  else run();
})();