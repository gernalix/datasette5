// click_to_filter.js — filtra per DATA (ignora l'ora) quando si clicca su una cella datetime
(function () {
  function pad2(n) { return String(n).padStart(2, "0"); }
  function parseDateOnly(text) {
    if (!text) return null;
    const s = text.trim().replace(/\u00A0/g, " ");
    let m = s.match(/^(\d{1,2})-(\d{1,2})-(\d{2}|\d{4})(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?$/);
    if (m) { let d=+m[1], mo=+m[2], y=m[3]; if (y.length===2) y="20"+y; return `${y}-${pad2(mo)}-${pad2(d)}`; }
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?$/);
    if (m) { let d=+m[1], mo=+m[2], y=m[3]; if (y.length===2) y="20"+y; return `${y}-${pad2(mo)}-${pad2(d)}`; }
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/);
    if (m) return `${m[1]}-${m[2]}-${m[3]}`;
    return null;
  }
  function baseTableUrl() {
    const path = window.location.pathname.replace(/\/+$/, "");
    const parts = path.split("/");
    if (parts.length && /^\d+$/.test(parts[parts.length - 1])) parts.pop();
    return parts.join("/");
  }
  document.addEventListener("click", function (ev) {
    const td = ev.target.closest("td");
    if (!td) return;
    const col = td.getAttribute("data-column") || (td.dataset && td.dataset.column);
    if (!col) return;
    const txt = (td.innerText || td.textContent || "").trim();
    const ymd = parseDateOnly(txt);
    if (!ymd) return;
    ev.preventDefault(); ev.stopPropagation();
    const url = baseTableUrl();
    const qs = new URLSearchParams();
    qs.set("_where", `DATE("${col}")=DATE('${ymd}')`);
    window.location.assign(`${url}?${qs.toString()}`);
  }, true);
})();