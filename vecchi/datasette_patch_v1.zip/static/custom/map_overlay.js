// map_overlay.js — aggiunge un solo pulsante "Mappa indirizzi" con guard
(function () {
  const BTN_ID = "btn-map-indirizzi";
  function isTablePage() {
    // evitiamo di mostrare su homepage database
    return /\/output\/[^\/]+$/.test(location.pathname) || /\/output\/[^\/]+\/\d+$/.test(location.pathname);
  }
  function ensureButton() {
    if (!isTablePage()) return;
    if (document.getElementById(BTN_ID)) return; // già presente
    const h1 = document.querySelector("h1");
    if (!h1) return;
    const btn = document.createElement("a");
    btn.id = BTN_ID;
    btn.href = "#";
    btn.textContent = " 📖 Mappa indirizzi";
    btn.className = "btn btn-secondary"; // Datasette style
    btn.style.marginLeft = "0.5rem";
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      // trigger logica mappa esistente (adatta al tuo progetto)
      window.dispatchEvent(new CustomEvent("open-address-map"));
    });
    h1.insertAdjacentElement("afterend", btn);
  }
  document.addEventListener("DOMContentLoaded", ensureButton);
  // se un altro script ricarica il titolo, riprova
  const obs = new MutationObserver(ensureButton);
  obs.observe(document.documentElement, { childList: true, subtree: true });
})();