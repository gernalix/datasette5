
(function () {
  function onReady(fn) {
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function isTimestampHeaderText(txt) {
    if (!txt) return false;
    txt = txt.trim().toLowerCase();
    const patterns = ['inizio','fine','timestamp','datetime','date','time'];
    if (patterns.includes(txt)) return true;
    return (/_at$|_time$|_timestamp$|_date$/.test(txt));
  }

  function applyNowrapAndWidths(table) {
    if (!table) return;
    const headers = table.querySelectorAll('thead th');
    headers.forEach((th, index) => {
      const name = (th.textContent || '').trim();
      if (isTimestampHeaderText(name)) {
        th.classList.add('ts-no-wrap');
        const tds = table.querySelectorAll('tbody tr td:nth-child(' + (index + 1) + ')');
        tds.forEach(td => td.classList.add('ts-no-wrap'));
      }
    });
  }

  function transformSexLink(table) {
    if (!table) return;
    const h1 = document.querySelector('h1');
    const isSex = h1 && /(^|\s)sex(\s|$)/i.test(h1.textContent);
    if (!isSex) return;
    let linkIdx = -1;
    const headers = table.querySelectorAll('thead th');
    headers.forEach((th, i) => {
      const name = (th.textContent || '').trim().toLowerCase();
      if (name === 'link') linkIdx = i;
    });
    if (linkIdx === -1) return;
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      const cell = row.querySelector('td:nth-child(' + (linkIdx + 1) + ')');
      if (!cell) return;
      let url = null;
      const a = cell.querySelector('a[href]');
      if (a) url = a.getAttribute('href');
      else {
        const text = (cell.textContent || '').trim();
        if (/^https?:\/\//i.test(text)) url = text;
      }
      if (url) {
        cell.innerHTML = '';
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener';
        link.textContent = '➡️';
        link.setAttribute('title', url);
        link.className = 'ts-emoji-link';
        cell.appendChild(link);
      }
    });
  }

  onReady(function () {
    const table = document.querySelector('table.table');
    if (!table) return;
    applyNowrapAndWidths(table);
    transformSexLink(table);
  });
})();
