
(function () {
  const HEADER_PATTERNS = ['inizio','fine','timestamp','datetime','date','time'];
  const HEADER_REGEX = /(_at|_time|_timestamp|_date|_dt|^ts$|^time$|^date$)/i;

  function onReady(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function isTimestampHeader(n){ if(!n) return false; n=n.trim().toLowerCase(); return HEADER_PATTERNS.includes(n)||HEADER_REGEX.test(n); }
  function textLen(el){ return (el.textContent||'').trim().length; }

  function fitTimestampColumns(table){
    const heads = table.querySelectorAll('thead th');
    heads.forEach((th, idx)=>{
      const name=(th.textContent||'').trim();
      if(!isTimestampHeader(name)) return;
      let maxLen = Math.max(textLen(th), 0);
      const cells = table.querySelectorAll('tbody tr td:nth-child('+(idx+1)+')');
      cells.forEach(td=>{
        const a=td.querySelector('a');
        const t=a?(a.textContent||a.href||''):(td.textContent||'');
        maxLen=Math.max(maxLen, t.trim().length);
        td.classList.add('ts-no-wrap');
      });
      const computed = Math.max(16, Math.min(32, maxLen+2)); // ch
      th.classList.add('ts-no-wrap');
      th.style.minWidth = computed+'ch';
      cells.forEach(td=>{ td.style.minWidth = computed+'ch'; });
    });
  }

  onReady(function(){
    const table = document.querySelector('table.table');
    if(!table) return;
    fitTimestampColumns(table);
  });
})();
