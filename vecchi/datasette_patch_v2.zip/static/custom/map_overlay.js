// map_overlay.js — garantisce UN solo pulsante e click funzionante
(function () {
  const BTN_ID = "btn-map-indirizzi";
  function isTableOrViewPage() {
    // /output/<table>   or   /output/<view>   or row detail /<id>
    return /^\/output\/[^\/]+(\/\d+)?$/.test(location.pathname);
  }
  function baseTablePath() {
    const parts = location.pathname.replace(/\/+$/, "").split("/");
    if (/^\d+$/.test(parts[parts.length-1])) parts.pop();
    return parts.join("/");
  }
  function ensureButton() {
    if (!isTableOrViewPage()) return;
    if (document.getElementById(BTN_ID)) return;
    const h1 = document.querySelector("h1");
    if (!h1) return;
    const a = document.createElement("a");
    a.id = BTN_ID;
    a.href = "#";
    a.textContent = " 📖 Mappa indirizzi";
    a.className = "btn btn-secondary";
    a.style.marginLeft = "0.6rem";
    a.addEventListener("click", function (e) {
      e.preventDefault();
      // 1) Se esiste una funzione globale nota, usala
      if (typeof window.openAddressMap === "function") return void window.openAddressMap();
      if (typeof window.renderAddressMapForCurrentTable === "function") return void window.renderAddressMapForCurrentTable();
      // 2) Se qualcuno ascolta eventi, prova vari nomi comuni
      const events = ["ds-open-address-map", "open-address-map", "open-map"];
      let dispatched = false;
      for (const name of events) {
        const ret = window.dispatchEvent(new CustomEvent(name, { bubbles: true }));
        dispatched = dispatched || ret;
      }
      if (dispatched) return;
      // 3) Fallback minimale: apri una vista JSON dei luoghi collegati (se disponibile via fix_links.js)
      const url = baseTablePath();
      const qs = new URLSearchParams(location.search);
      // lascia i filtri correnti e lascia che altri script costruiscano la mappa
      window.location.assign(url + "?" + qs.toString());
    });
    h1.insertAdjacentElement("afterend", a);
  }
  document.addEventListener("DOMContentLoaded", ensureButton);
  new MutationObserver(ensureButton).observe(document.documentElement, { childList: true, subtree: true });
})();
