// static/custom/calendar_range_split.js (safe version)
// - Splits calendar_range into per-`tab` tables.
// - Waits for table + rows, clones rows, hides original afterwards.
// - Removes 'Advanced export' + SQL block for this page.
(function(){
  function isCalendarRange(){
    return /\/calendar_range(?:$|[/?#])/.test(location.pathname);
  }
  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }

  async function waitForTable(timeoutMs){
    const start = Date.now();
    while (Date.now() - start < timeoutMs){
      const tbl = qs("table.rows-and-columns");
      if (tbl){
        const rows = qsa("tbody tr", tbl);
        if (rows.length) return tbl;
      }
      await new Promise(r => setTimeout(r, 100));
    }
    return null;
  }

  function removeAdvanced(){
    // remove SQL blocks
    qsa("pre.sql, .sql").forEach(el => el.remove());
    // heuristics: any block whose first text contains 'Advanced export'
    qsa("details, section, aside, div").forEach(el => {
      const t = (el.textContent || "").trim();
      if (/^Advanced export/i.test(t)) el.remove();
    });
  }

  async function run(){
    if (!isCalendarRange()) return;
    const base = await waitForTable(2500);
    if (!base) return; // nothing to do

    const ths = qsa("thead th", base);
    const headers = ths.map(th => (th.textContent || "").trim().toLowerCase());
    const tabIdx = headers.indexOf("tab");
    if (tabIdx === -1) return;

    const rows = qsa("tbody tr", base);
    if (!rows.length) return;

    // Group clones by tab
    const groups = new Map();
    for (const tr of rows){
      const tds = tr.querySelectorAll("td");
      const tab = (tds[tabIdx]?.textContent || "").trim() || "(vuoto)";
      if (!groups.has(tab)) groups.set(tab, []);
      groups.get(tab).push(tr.cloneNode(true));
    }
    if (groups.size === 0) return;

    // Build container and grouped tables
    const container = document.createElement("div");
    container.id = "cr-split-container";
    container.style.marginTop = "1rem";

    for (const [tab, trs] of groups){
      // Title
      const h = document.createElement("h2");
      h.textContent = tab;
      h.style.fontSize = "1.15rem";
      h.style.margin = "1.2rem 0 0.5rem";
      container.appendChild(h);

      const tbl = document.createElement("table");
      tbl.className = base.className;

      // thead
      const thead = document.createElement("thead");
      const hr = document.createElement("tr");
      for (const th of ths) hr.appendChild(th.cloneNode(true));
      thead.appendChild(hr);
      tbl.appendChild(thead);

      // tbody
      const tbody = document.createElement("tbody");
      trs.forEach(tr => tbody.appendChild(tr));
      tbl.appendChild(tbody);

      container.appendChild(tbl);
    }

    // Insert and hide base table
    base.insertAdjacentElement("afterend", container);
    base.style.display = "none";

    // Remove advanced export + SQL
    removeAdvanced();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run);
  else run();
})();