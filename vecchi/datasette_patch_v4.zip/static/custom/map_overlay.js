// map_overlay.js — bottone unico + dispatch eventi
(function () {
  const BTN_ID = "btn-map-indirizzi";
  function onTablePage() {
    return /^\/output\/[^\/]+(\/\d+)?$/.test(location.pathname);
  }
  function container() {
    return document.querySelector('.content h1, h1.title, .page-title, h1') || document.body;
  }
  function ensureButton() {
    if (!onTablePage()) return;
    if (document.getElementById(BTN_ID)) return;
    const where = container(); if (!where) return;
    const a = document.createElement('a');
    a.id = BTN_ID; a.href = '#'; a.textContent = ' 🗺️ Mappa indirizzi';
    a.className = 'btn btn-secondary'; a.style.marginLeft = '0.6rem';
    a.addEventListener('click', function (e) {
      e.preventDefault();
      if (typeof window.openAddressMap === 'function') return void window.openAddressMap();
      if (typeof window.renderAddressMapForCurrentTable === 'function') return void window.renderAddressMapForCurrentTable();
      const events = ['ds-open-address-map', 'open-address-map', 'open-map'];
      let any = false;
      for (const ev of events) { const ok = window.dispatchEvent(new CustomEvent(ev, { bubbles: true })); any = any || ok; }
      if (!any) alert('Nessun handler mappa disponibile. Verifica calendar_range_map.js o definisci window.openAddressMap().');
    });
    where.insertAdjacentElement('afterend', a);
  }
  document.addEventListener('DOMContentLoaded', ensureButton);
  new MutationObserver(ensureButton).observe(document.documentElement, { childList: true, subtree: true });
})();