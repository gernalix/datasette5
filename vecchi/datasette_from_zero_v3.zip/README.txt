
Bundle from zero (v3) — include tre modalità di avvio:

1) run_tailscale_https.bat       -> NORMALE (templates + /custom)
2) run_safe_no_templates_https.bat -> SAFE (isola eventuali errori template)
3) run_debug_https.bat           -> DEBUG (log esteso su run.log)

Uso consigliato:
- Se /output dà Internal Server Error, prova il SAFE:
  - Se SAFE funziona, il problema è in qualche template/custom
  - Se SAFE non funziona, controlla il DB con check_db.bat

Check rapido DB:
- Esegui check_db.bat (usa verify_db.py)
- Vedi integrity_check e presenza di 'calendar' e 'calendar_range'

Ricorda di creare/aggiornare la VIEW nel DB:
DROP VIEW IF EXISTS calendar_range;
CREATE VIEW calendar_range AS
SELECT
  giorno,
  ts,
  tab,
  col,
  pk_json,
  CASE
    WHEN link LIKE 'http%' THEN link
    ELSE 'https://daniele.tail6b4058.ts.net:8001' || link
  END AS link
FROM calendar;
