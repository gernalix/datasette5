(function () {
  const ABS_BASE = "https://daniele.tail6b4058.ts.net:8001";
  function fixAll() {
    document.querySelectorAll('td[data-column="link"]').forEach(td => {
      const raw = (td.textContent || "").trim();
      if (!raw || td.dataset.fixed === "1") return;
      td.dataset.fixed = "1";
      const url = raw.startsWith("http") ? raw : (ABS_BASE + raw);
      td.innerHTML = `<a href="${url}" target="_blank" title="${url}" style="text-decoration:none;font-size:1.25em;">➡️</a>`;
    });
  }
  window.addEventListener("load", fixAll);
  new MutationObserver(fixAll).observe(document.body, { childList: true, subtree: true });
})();