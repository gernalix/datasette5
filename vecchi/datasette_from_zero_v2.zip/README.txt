
Setup (da zero)

1) Copia tutto in Z:\download\datasette5
2) Metti qui il tuo output.db
3) Lancia run_tailscale_https.bat
   - Questo .bat monta i templates e /custom correttamente:
     --template-dir templates
     --static custom:custom
   - HTTPS con i tuoi certificati

4) Assicurati che la VIEW esista nel DB:
   DROP VIEW IF EXISTS calendar_range;
   CREATE VIEW calendar_range AS
   SELECT
     giorno,
     ts,
     tab,
     col,
     pk_json,
     CASE
       WHEN link LIKE 'http%' THEN link
       ELSE 'https://daniele.tail6b4058.ts.net:8001' || link
     END AS link
   FROM calendar;

5) Apri https://daniele.tail6b4058.ts.net:8001/output/calendar_range

Note: fix_links.js rende la colonna 'link' una emoji ➡️ con URL assoluto
e click_to_filter.js ripristina il comportamento di filtro sulle celle.
