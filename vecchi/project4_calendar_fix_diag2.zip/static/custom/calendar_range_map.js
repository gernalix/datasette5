// static/custom/calendar_range_map.js  (per-view script)
(function(){

  function asRows(data){
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.rows)) return data.rows;
    if (data && Array.isArray(data["rows"])) return data["rows"];
    return [];
  }

  function onReady(fn){
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }
  function isCalendarRange(){
    return /\/calendar_range(?:$|[/?#])/.test(location.pathname);
  }
  function addButton(){
    const h1=document.querySelector("h1");
    if(!h1) return;
    const b=document.createElement("button");
    b.textContent="🗺️ Mappa indirizzi";
    b.className="btn btn-sm";
    b.style.marginLeft="1rem";
    b.addEventListener("click", run);
    h1.appendChild(b);
  }
  function jsonURL(path){
    const u=new URL(location.href);
    u.pathname = (path || u.pathname).replace(/\/$/,"") + ".json";
    u.searchParams.set("_shape","objects");
    u.searchParams.set("_size","max");
    return u.toString();
  }
  function ensureLeaflet(){
    if (window.L && L.map) return Promise.resolve();
    const link=document.createElement("link");
    link.rel="stylesheet";
    link.href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    return new Promise((res,rej)=>{
      const s=document.createElement("script");
      s.src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
      s.onload=res; s.onerror=rej;
      document.head.appendChild(s);
    });
  }
  
async function run(){
  try{
    const testUrl = jsonURL();
    console.debug("[calendar_range_map] fetching rows from", testUrl);
  }catch(e){ console.error("[calendar_range_map] building jsonURL failed", e); alert("URL JSON non valido: " + (e && e.message)); return; }

    try{
      const respRows = await fetch(jsonURL(), {credentials:"same-origin"});
      if(!respRows.ok){ console.error('[calendar_range_map] rows fetch failed', respRows.status, respRows.statusText); throw new Error('rows fetch failed'); }
      const dataRows = await respRows.json();
      const rows = asRows(dataRows);
      console.debug('[calendar_range_map] rows count', rows.length, dataRows);
      const whitelist=new Set(["sex","ex_sex","ex_negozi","ex_super","negozi","luogo"]);
      const luogoIds=[];
      for(const r of rows){
        const tab=(r.tab||"").toString();
        if(!whitelist.has(tab)) continue;
        let pk=null;
        try{ pk=(typeof r.pk_json==="string")? JSON.parse(r.pk_json): r.pk_json; }catch(e){}
        const id = pk && (pk.id || pk.pk || pk.rowid);
        if(!id) continue;
        // fetch record to get luogo_id
        const u=new URL(location.href);
        u.pathname = u.pathname.replace(/\/calendar_range.*/, "") + "/" + encodeURIComponent(tab) + "/" + encodeURIComponent(id) + ".json";
        u.search="?_shape=objects&_size=1";
        const respRec = await fetch(u.toString(), {credentials:"same-origin"});
        if(!respRec.ok){ console.error('[calendar_range_map] record fetch failed', u.toString(), respRec.status, respRec.statusText); continue; }
        const dataRec = await respRec.json();
        const arr = asRows(dataRec);
        const rec = Array.isArray(arr) ? arr[0] : (dataRec || null);
        const luogo_id = rec && (rec.luogo_id ?? null);
        if(luogo_id!=null) luogoIds.push(luogo_id);
      }
      const ids=[...new Set(luogoIds)];
      if(!ids.length){ alert("Nessun luogo disponibile per questa selezione."); return; }
      await ensureLeaflet();
      // modal
      const modal=document.createElement("div");
      Object.assign(modal.style, {position:"fixed", inset:"5%", background:"white", border:"1px solid #ccc", zIndex:9999, boxShadow:"0 10px 30px rgba(0,0,0,.3)"});
      const close=document.createElement("button");
      close.textContent="✖";
      Object.assign(close.style, {position:"absolute", top:"8px", right:"8px"});
      close.onclick=()=>modal.remove();
      const mapDiv=document.createElement("div");
      Object.assign(mapDiv.style, {position:"absolute", top:"48px", left:0, right:0, bottom:0});
      modal.appendChild(close); modal.appendChild(mapDiv); document.body.appendChild(modal);
      const m=L.map(mapDiv).setView([55.6761,12.5683], 11);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(m);
      const m2=location.pathname.match(/^\/([^/]+)/); const db = m2? m2[1]: "output";
      for(const id of ids){
        const u=new URL(location.href);
        u.pathname = "/" + db + "/luogo/" + encodeURIComponent(id) + ".json";
        u.search="?_shape=objects&_size=1";
        const respLuogo = await fetch(u.toString(),{credentials:"same-origin"});
        if(!respLuogo.ok){ console.error('[calendar_range_map] luogo fetch failed', u.toString(), respLuogo.status, respLuogo.statusText); continue; }
        const arr = await respLuogo.json();
        const rec = Array.isArray(arr)? arr[0]: null;
        if(!rec) continue;
        const lat= rec.lat ?? rec.latitude;
        const lon= rec.lon ?? rec.longitude ?? rec.lng;
        if(lat==null || lon==null) continue;
        const marker=L.marker([+lat,+lon]).addTo(m);
        marker.bindPopup(rec.indirizzo || ("luogo #" + id));
      }
      try{ m.fitBounds(m.getBounds().pad(0.2)); }catch(e){}
    }catch(e){
      console.error("calendar_range_map error", e);
      alert("Errore durante il caricamento della mappa. Controlla la console per i dettagli.");
    }
  }
  onReady(function(){

  function asRows(data){
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.rows)) return data.rows;
    if (data && Array.isArray(data["rows"])) return data["rows"];
    return [];
  }

    if(!isCalendarRange()) return;
    addButton();
  });
})();