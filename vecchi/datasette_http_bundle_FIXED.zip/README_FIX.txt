Quick start (Windows)

1) (Consigliato) Crea un virtualenv accanto ai file:
   python -m venv .venv
   .venv\Scripts\pip install datasette

2) Avvio locale (HTTP):
   - Doppio click su: run_local_http.bat
   - Apri: http://127.0.0.1:8001/

3) Avvio remoto via ngrok (HTTPS):
   - Installa ngrok e aggiungilo al PATH
   - Doppio click su: run_ngrok_https.bat
   - Apri l'URL https mostrato dalla console ngrok

Note importanti:
- Questo bundle non forza mai "https://" all'interno di Datasette: il server locale resta HTTP.
  Se ti serve HTTPS pubblico usa ngrok o un reverse proxy.
- Opzioni incluse automaticamente se presenti nel bundle:
  * metadata.json
  * templates (con --template-dir)
  * static/custom (mappato su /custom) oppure l'intera cartella /static
  * plugins (con --plugins-dir)
- Porta predefinita: 8001. Se vuoi cambiarla, modifica i .bat e sostituisci 8001 con la porta desiderata.

Rilevati nel pacchetto:
- DB principale: non trovato
- metadata.json: sì
- templates/: sì
- static/: sì
- plugins/: no