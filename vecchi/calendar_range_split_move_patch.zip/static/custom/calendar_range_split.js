// static/custom/calendar_range_split.js
// Splits /calendar_range into separate tables per `tab` (moves rows, no duplicates)
(function(){
  function onReady(fn){
    if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }
  function isCalendarRange(){
    return /\/calendar_range(?:$|[/?#])/.test(location.pathname);
  }

  function split(){
    const base = document.querySelector("table.rows-and-columns");
    if(!base) return;

    // Grab headers and find index of 'tab'
    const ths = Array.from(base.querySelectorAll("thead th"));
    const headers = ths.map(th => (th.textContent || "").trim().toLowerCase());
    const tabIdx = headers.indexOf("tab");
    if(tabIdx === -1) return;

    const groups = new Map(); // tab -> [TR nodes]
    const rows = Array.from(base.querySelectorAll("tbody tr"));
    if(!rows.length) return;

    // Move rows into groups
    for(const tr of rows){
      const tds = tr.querySelectorAll("td");
      const tab = (tds[tabIdx]?.textContent || "").trim() || "(vuoto)";
      if(!groups.has(tab)) groups.set(tab, []);
      groups.get(tab).push(tr);
    }

    // Build container after the base table
    const container = document.createElement("div");
    container.id = "cr-split-container";
    container.style.marginTop = "1rem";

    // Create one table per group
    for(const [tab, trs] of groups){
      // Title
      const h = document.createElement("h2");
      h.textContent = tab;
      h.style.fontSize = "1.15rem";
      h.style.margin = "1.2rem 0 0.5rem";
      container.appendChild(h);

      // New table with same classes
      const tbl = document.createElement("table");
      tbl.className = base.className; // keep 'rows-and-columns' etc.

      // Copy thead
      const thead = document.createElement("thead");
      const hr = document.createElement("tr");
      for(const th of ths){
        hr.appendChild(th.cloneNode(true));
      }
      thead.appendChild(hr);
      tbl.appendChild(thead);

      // New tbody and MOVE rows (no duplicates in DOM)
      const tbody = document.createElement("tbody");
      for(const tr of trs){
        tbody.appendChild(tr); // moves the existing node
      }
      tbl.appendChild(tbody);

      container.appendChild(tbl);
    }

    // Remove original (now-empty) base table from DOM
    base.parentNode.removeChild(base);
  }

  onReady(function(){
    if(!isCalendarRange()) return;
    try{ split(); }catch(e){ console.error("calendar_range_split error", e); }
  });
})();