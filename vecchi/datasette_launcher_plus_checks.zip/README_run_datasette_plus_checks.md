
# Datasette launcher with asset checks

This `run_datasette_plus_checks.bat` does three things:
1) Serves your **custom JS/CSS** that format tables (dates `dd-mm-yy hh:mm`, boolean emojis, hide all‑false/empty columns, hide gray counters, etc.).  
2) **Logs** any missing assets (JS/CSS/templates) to `logs\datasette_YYYY-MM-DD_HH-MM-SS.log`.  
3) Pops a **Windows popup** if critical assets are missing, so you notice right away.

## Folder layout expected

Place the BAT in your project root, together with:
```
output.db
metadata.json            (optional but recommended)
templates\base.html     (must include the <link>/<script> tags for your assets)
static\custom\desktop.css
static\custom\mobile.css
static\custom\click_to_filter.js
static\custom\date_range_filter.js
plugins\                (optional)
```
If you use different filenames/paths, edit the variables at the top of the BAT.

## How it ensures the formatting code runs

- The `--template-dir templates` flag lets `base.html` inject your custom CSS/JS into **all tables/views**.
- The `--static custom:static\custom` flag exposes your assets under `/custom/...` so `base.html` lines like
  ```html
  <link rel="stylesheet" href="/custom/desktop.css">
  <script defer src="/custom/click_to_filter.js"></script>
  ```
  can load correctly.
- If an asset is missing, the launcher writes a **[WARN]** or **[ERROR]** line in the log and shows a popup.

## Opening the app

It starts on `http://127.0.0.1:8001/output` by default. Change `PORT`/`HOST` in the BAT if needed.

## Troubleshooting

- If you still see the **raw** table (no emojis/date format), check the latest file in `logs\`.
- Make sure `templates\base.html` actually includes your `<link>`/`<script>` to `/custom/...`.
- If `plugins\` exists, it's used; otherwise the launcher continues without it.
