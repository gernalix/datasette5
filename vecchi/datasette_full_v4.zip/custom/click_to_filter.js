(function(){
  function startswith(s,p){return s.slice(0,p.length)===p}
  String.prototype.startswith = function(p){return startswith(this,p)}
  const tableSel = '#rows-and-columns table';
  function applyClick() {
    const table = document.querySelector(tableSel);
    if(!table) return;
    table.querySelectorAll('tbody td').forEach(td => {
      if (td.dataset.ctf==="1") return;
      td.dataset.ctf="1";
      td.style.cursor = "pointer";
      td.addEventListener('click', (ev) => {
        const col = td.getAttribute('data-column') || (table.querySelectorAll('thead th')[td.cellIndex]?.getAttribute('data-column'));
        if(!col) return;
        const val = td.textContent.trim();
        const u = new URL(window.location.href);
        if (ev.ctrlKey || ev.metaKey) {
          const idx = Array.from(u.searchParams.keys()).filter(k=>k.startswith('_filter_column_')).length + 1;
          u.searchParams.set(`_filter_column_${idx}`, col);
          u.searchParams.set(`_filter_op_${idx}`, 'exact');
          u.searchParams.set(`_filter_value_${idx}`, val);
        } else {
          Array.from(u.searchParams.keys()).forEach(k=>{ if(k.startswith('_filter_')) u.searchParams.delete(k); });
          u.searchParams.set('_filter_column_1', col);
          u.searchParams.set('_filter_op_1', 'exact');
          u.searchParams.set('_filter_value_1', val);
        }
        window.location.href = u.toString();
      });
    });
  }
  window.addEventListener('load', applyClick);
  new MutationObserver(applyClick).observe(document.body, {childList:true, subtree:true});
})();