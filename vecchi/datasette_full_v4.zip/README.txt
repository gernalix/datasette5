
Datasette full bundle (senza output.db) — cartella target: Z:\download\datasette5

1) Copia TUTTI i file di questo ZIP in Z:\download\datasette5
2) Metti nella stessa cartella il tuo output.db
3) Avvio consigliato: run_tailscale_https.bat  (templates + custom caricati)
   Alternative: run_safe_no_templates_https.bat  (diagnostica), run_debug_https.bat (log in run.log)

Certificati HTTPS usati:
  C:\Users\seste\daniele.tail6b4058.ts.net.crt
  C:\Users\seste\daniele.tail6b4058.ts.net.key

Note formattazioni:
- custom/styles.css + custom/formatting.js applicano header sticky, numeri a dx, date monospazio,
  badge per 0/1, gestione null. fix_links.js trasforma le colonne "link" in emoji ➡️ con URL assoluti.
- templates/base.html estende 'default:base.html' (compatibile con Datasette 0.65.x) e carica tutti i CSS/JS.

View utile per i link assoluti (se non esiste già):
DROP VIEW IF EXISTS calendar_range;
CREATE VIEW calendar_range AS
SELECT
  giorno, ts, tab, col, pk_json,
  CASE WHEN link LIKE 'http%' THEN link
       ELSE 'https://daniele.tail6b4058.ts.net:8001' || link END AS link
FROM calendar;
