// static/custom/calendar_range_split.js (fetch-render version)
(function(){
  function isCalendarRange(){ return /\/calendar_range(?:$|[/?#])/.test(location.pathname); }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const qs  = (s, r)=> (r||document).querySelector(s);
  const qsa = (s, r)=> Array.from((r||document).querySelectorAll(s));
  function getDbName(){ const p=location.pathname.split("/").filter(Boolean); return p[0]||""; }
  function parseIdFromHref(href){
    try{ const u=new URL(href, location.origin);
      const seg=u.pathname.split("/").filter(Boolean);
      const last=seg.pop(); if(/^\d+$/.test(last)) return last;
      const id=u.searchParams.get("id"); if(id) return id;
    }catch(e){} return null;
  }
  async function waitForBase(timeout=2500){
    const start=Date.now();
    while(Date.now()-start<timeout){
      const tbl=qs("table.rows-and-columns");
      if(tbl && qsa("tbody tr", tbl).length) return tbl;
      await new Promise(r=>setTimeout(r,100));
    }
    return null;
  }
  async function fetchColumns(db, table){
    const sql="PRAGMA table_info('"+table.replace(/'/g,"''")+"')";
    const url=`/${db}.json?sql=`+encodeURIComponent(sql)+`&_shape=objects`;
    const r=await fetch(url); if(!r.ok) throw new Error("columns "+r.status);
    const data=await r.json();
    const rows=Array.isArray(data?.rows)?data.rows:(Array.isArray(data)?data:[]);
    return rows.sort((a,b)=>a.cid-b.cid).map(x=>x.name);
  }
  async function fetchRows(db, table, ids){
    const where="id in ("+ids.join(",")+")";
    const params=new URLSearchParams({_shape:"objects",_size:"max",_where:where,_labels:"on"});
    const url=`/${db}/${encodeURIComponent(table)}.json?`+params.toString();
    const r=await fetch(url); if(!r.ok) throw new Error("rows "+r.status);
    const data=await r.json();
    return Array.isArray(data?.rows)?data.rows:(Array.isArray(data)?data:[]);
  }
  function renderTable(title, columns, rows, db, table){
    const frag=document.createDocumentFragment();
    const h=document.createElement("h2"); h.textContent=title; h.style.fontSize="1.15rem"; h.style.margin="1.2rem 0 0.5rem"; frag.appendChild(h);
    const tbl=document.createElement("table"); tbl.className="rows-and-columns";
    const thead=document.createElement("thead"); const hr=document.createElement("tr");
    columns.forEach(c=>{ const th=document.createElement("th"); th.textContent=c; hr.appendChild(th); });
    thead.appendChild(hr); tbl.appendChild(thead);
    const tbody=document.createElement("tbody");
    rows.forEach(row=>{
      const tr=document.createElement("tr");
      columns.forEach(col=>{
        const td=document.createElement("td");
        const val=row[col];
        if(col.toLowerCase()==="id" && val!=null){
          const a=document.createElement("a"); a.href=`/${db}/${encodeURIComponent(table)}/${val}`; a.textContent=val; td.appendChild(a);
        }else if(col.toLowerCase()==="link" && typeof val==="string"){
          const a=document.createElement("a"); a.href=val; a.target="_blank"; a.rel="noopener"; a.textContent="➡️"; td.appendChild(a);
        }else{
          td.textContent=(val==null)?"":String(val);
        }
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    tbl.appendChild(tbody); frag.appendChild(tbl); return frag;
  }
  function removeAdvanced(){
    qsa("pre.sql, .sql").forEach(el=>el.remove());
    qsa("details, section, aside, div").forEach(el=>{ const t=(el.textContent||"").trim(); if(/^Advanced export/i.test(t)) el.remove(); });
  }
  async function run(){
    if(!isCalendarRange()) return;
    const base=await waitForBase(); if(!base) return;
    const db=getDbName();
    const headers=qsa("thead th", base).map(th=>(th.textContent||"").trim().toLowerCase());
    const tabIdx=headers.indexOf("tab"); const linkIdx=headers.indexOf("link"); if(tabIdx===-1||linkIdx===-1) return;
    const groups=new Map();
    qsa("tbody tr", base).forEach(tr=>{
      const tds=tr.querySelectorAll("td");
      const tab=(tds[tabIdx]?.textContent||"").trim();
      const a=tds[linkIdx]?.querySelector("a");
      const id=a?parseIdFromHref(a.href):null;
      if(!tab||!id) return;
      if(!groups.has(tab)) groups.set(tab,new Set());
      groups.get(tab).add(id);
    });
    if(!groups.size) return;
    const container=document.createElement("div"); container.id="cr-split-container"; container.style.marginTop="1rem";
    for(const [tab, idSet] of groups){
      const ids=[...idSet];
      try{
        const cols=await fetchColumns(db, tab);
        const rows=await fetchRows(db, tab, ids);
        container.appendChild(renderTable(tab, cols, rows, db, tab));
      }catch(e){ console.error("calendar_range render failed", tab, e); }
    }
    base.insertAdjacentElement("afterend", container);
    base.style.display="none";
    removeAdvanced();
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", run); else run();
})();